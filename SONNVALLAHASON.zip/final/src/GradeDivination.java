import java.io.*;
import java.util.*;

public class GradeDivination {

    private final Scanner input = new Scanner(System.in);
    private String currentGroup = "";

    // Constants aligned with the final, robust structure
    private static final String GROUPS_ROSTER_FILE = "groups.csv"; // Student Name,Group ID
    private static final String GRADE_FILE_EXTENSION = ".csv";

    public void showGradeDivination() {
        System.out.println("== Grading System Setup ==");

        // 1. CHOOSE THE GROUP
        currentGroup = selectGroup();
        if (currentGroup.isEmpty()) {
            System.out.println("Group selection cancelled or failed. Returning...");
            return;
        }

        System.out.println("Selected Group: " + currentGroup);

        // Use the selected group to find its specific criteria file (e.g., grades_A.csv)
        String filename = getFilename(currentGroup);
        File file = new File(filename);

        // --- 2. CHECK AND DISPLAY CRITERIA ---

        // If file doesn't exist or is empty, force setup
        if (!file.exists() || file.length() == 0) {
            String message = file.exists() ? "You haven't entered any grades" : "Criteria file not found";
            System.out.println(message + " for group '" + currentGroup + "'. Setting up new grading criteria.");
            setupGrades();
            return;
        }

        // If file exists, display current criteria
        System.out.println("\n✅ Current grading criteria for group '" + currentGroup + "':");
        displayGrades(filename);

        // --- 3. ASK FOR CHANGES ---
        System.out.print("Do you want to make any changes to the grading criteria (weights) for '" + currentGroup + "' (y/n)? ");
        String ans = input.nextLine().trim();

        if (ans.equalsIgnoreCase("y")) {
            setupGrades();
        } else {
            System.out.println("Criteria retained. Returning to the main menu...");
        }
    }

    // --- METHOD TO CHOOSE (SELECT) THE GROUP ---
    private String selectGroup() {
        Map<Integer, String> groupMap = new HashMap<>();

        // 1. Read the roster file to find all unique group IDs
        // This is where we get the list of groups to choose from.
        Map<String, String> fullRoster = readFullGroupRoster();
        Set<String> uniqueGroups = new HashSet<>(fullRoster.values());

        if (uniqueGroups.isEmpty() || (uniqueGroups.size() == 1 && uniqueGroups.contains(""))) {
            // Handle case where file is empty or only contains the header
            System.out.println("⚠️ No groups found in " + GROUPS_ROSTER_FILE + ". Check your file setup.");
            return "";
        }

        // 2. Map unique groups to numbered selection options
        int count = 1;
        for (String groupID : uniqueGroups) {
            if (!groupID.isEmpty()) { // Ensure we don't map an empty group ID
                groupMap.put(count, groupID);
                count++;
            }
        }

        System.out.println("\nSelect a Group to work with:");
        for (Map.Entry<Integer, String> entry : groupMap.entrySet()) {
            System.out.println("  " + entry.getKey() + ") " + entry.getValue());
        }

        while (true) {
            System.out.print("Enter the number of the group: ");
            String line = input.nextLine().trim();
            try {
                int selection = Integer.parseInt(line);
                if (groupMap.containsKey(selection)) {
                    return groupMap.get(selection); // Return the selected group name
                } else {
                    System.out.println("Invalid selection. Please enter a number from the list.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    // --- HELPER METHODS ---

    // Reads the entire roster file (Student Name -> Group ID) to find unique groups
    private Map<String, String> readFullGroupRoster() {
        Map<String, String> roster = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(GROUPS_ROSTER_FILE))) {
            String line;
            boolean isHeader = true;
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) continue;
                if (isHeader) { // Skip header row
                    isHeader = false;
                    continue;
                }

                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String studentName = parts[0].trim();
                    String groupID = parts[1].trim().toUpperCase();
                    roster.put(studentName, groupID);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: Roster file '" + GROUPS_ROSTER_FILE + "' not found.");
        } catch (IOException e) {
            System.out.println("Error reading roster file: " + e.getMessage());
        }
        return roster;
    }

    private String getFilename(String group) {
        return "grades_" + group + GRADE_FILE_EXTENSION;
    }

    // Reads grades from the specific file and prints to screen
    private void displayGrades(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                System.out.println("• " + line);
            }
            System.out.println();
        } catch (IOException e) {
            System.out.println("Error reading grades for group '" + currentGroup + "': " + e.getMessage());
        }
    }

    // Collects grades from user, checks sum=100, writes to the group-specific file
    private void setupGrades() {
        boolean running = true;
        String filename = getFilename(currentGroup);

        while (running) {
            System.out.println("\nEnter grading components for group '" + currentGroup + "' (example: Midterm 30)");
            System.out.println("Press ENTER on an empty line to stop.");

            int sum = 0;
            StringBuilder finalText = new StringBuilder();

            while (true) {
                System.out.print("> ");
                String line = input.nextLine().trim();

                if (line.isEmpty()) break;

                String[] parts = line.split(" ");
                if (parts.length < 2) {
                    System.out.println("Please provide a component name and a score. Try again.");
                    continue;
                }

                String last = parts[parts.length - 1];

                int mark;
                try {
                    mark = Integer.parseInt(last);
                } catch (NumberFormatException e) {
                    System.out.println("The last part of the line must be a number (the weight). Try again.");
                    continue;
                }

                sum += mark;
                finalText.append(line).append("\n");
            }

            if (sum != 100) {
                System.out.println("Total must be 100. Yours = " + sum + ". Try again!\n");
                continue;
            }

            // Write to the group-specific CSV file
            try (FileWriter writer = new FileWriter(filename)) {
                writer.write(finalText.toString());
            } catch (IOException e) {
                System.out.println("Error writing to file for group '" + currentGroup + "': " + e.getMessage());
            }

            System.out.println("Grades for group '" + currentGroup + "' saved! Total = 100.");

            System.out.print("Do you want to change anything for group '" + currentGroup + "'? (y/n): ");
            running = input.nextLine().equalsIgnoreCase("y");
        }
    }
}
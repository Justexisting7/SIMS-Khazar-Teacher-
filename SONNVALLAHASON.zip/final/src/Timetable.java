import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Timetable {

    private static final String COLUMN_FORMAT = "%-20s";

    public void showTimetable() {
        System.out.println("== Lesson Schedule ==");
        File file = new File("schedule.csv");

        if (!file.exists()) {
            System.out.println("The schedule file couldn't be found!");
            return;
        } else if (file.length() == 0) {
            System.out.println("The schedule has not been set yet.");
            return;
        }

        showSchedule(file);
    }

    public void showSchedule(File file) {
        //And this is where we store our data.This line of code helps us to read the data row by row
        List<String[]> rows = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = br.readLine()) != null) {
                rows.add(line.split(","));
            }
        } catch (IOException e) {
            System.out.println("Error reading schedule file! " + e.getMessage());
            return;
        }

        System.out.println("\n---- Schedule ----");

        String[] header = rows.get(0);
        int columnCount = header.length;

        PrintRow(header, columnCount);
        PrintLine(columnCount);

        for (int i = 1; i < rows.size(); i++) {
            PrintRow(rows.get(i), columnCount);
        }
    }

    private void PrintRow(String[] row, int columnCount) {
        for (int i = 0; i < columnCount; i++) {
            String cell = (i < row.length) ? row[i].trim() : "";
            System.out.printf(COLUMN_FORMAT + "| ", cell);
        }
        System.out.println();
    }

    private void PrintLine(int numColumns) {
        int separatorWidth = numColumns * (20 + 2);
        for (int i = 0; i < separatorWidth; i++) {
            System.out.print("-");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        new Timetable().showTimetable();
    }
}

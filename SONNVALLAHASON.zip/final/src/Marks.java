import java.io.*;
import java.util.*;
import java.util.stream.Collectors;

public class Marks { // Note: This class handles Mark Entry logic

    private final Scanner input = new Scanner(System.in);
    private String currentGroup = "";

    // Constants
    private static final String GROUPS_ROSTER_FILE = "groups.csv"; // Student Name,Group ID

    public void showMarks() {
        System.out.println("== Enter Student Marks ==");

        // 1. Get the group name using the robust selection method
        currentGroup = selectGroup();
        if (currentGroup.isEmpty()) {
            System.out.println("Group selection cancelled or failed. Returning to the main menu...");
            return;
        }

        System.out.println("Preparing to grade marks for Group: " + currentGroup);

        do {
            // 2. Define dynamic filenames
            String gradeFileName = getGradeFilename(currentGroup);
            String marksFileName = getMarksFilename(currentGroup);

            // Read the criteria (e.g., Midterm, Final)
            List<String[]> gradesCriteria = readGradeCriteria(gradeFileName);
            if (gradesCriteria.isEmpty()) {
                System.out.println("ERROR: Grade criteria not found for group '" + currentGroup + "'. Set up grades first.");
                return;
            }

            // Read student names
            List<String> students = readStudents("students.txt");
            if (students.isEmpty()) {
                System.out.println("ERROR: No students found in students.txt.");
                return;
            }

            // Read existing marks for the group
            Map<String, Map<String, String>> existingMarks = readExistingMarks(marksFileName);

            // 3. Select which component to grade
            String componentName = selectGradingComponent(gradesCriteria);
            if (componentName == null) {
                System.out.println("Operation cancelled.");
                return;
            }

            // Get the max mark (weight) for the selected component
            int maxMark = getMaxMarkForComponent(componentName, gradesCriteria);
            if (maxMark == -1) {
                System.out.println("ERROR: Could not find a valid weight for the component: " + componentName);
                return;
            }

            // 4. Input marks for the selected component
            inputMarksForComponent(students, componentName, existingMarks, maxMark);

            // 5. Save the updated marks
            saveMarksToFile(marksFileName, existingMarks);

            // 6. Ask if they want to make more changes
            System.out.print("\nDo you want to make any differences or enter another component's marks (y/n)? ");
        } while (input.nextLine().trim().equalsIgnoreCase("y"));

        System.out.println("Mark entry process finished for group: " + currentGroup + ".");
    }

    // --- Core Group Selection Methods ---

    private String selectGroup() {
        Map<Integer, String> groupMap = new HashMap<>();
        Map<String, String> fullRoster = readFullGroupRoster();
        Set<String> uniqueGroups = new HashSet<>(fullRoster.values());

        if (uniqueGroups.isEmpty() || (uniqueGroups.size() == 1 && uniqueGroups.contains(""))) {
            System.out.println("⚠️ No groups found in " + GROUPS_ROSTER_FILE + ". Check your file setup.");
            return "";
        }

        int count = 1;
        for (String groupID : uniqueGroups) {
            if (!groupID.isEmpty()) {
                groupMap.put(count, groupID);
                count++;
            }
        }

        System.out.println("\nSelect a Group to work with:");
        for (Map.Entry<Integer, String> entry : groupMap.entrySet()) {
            System.out.println("  " + entry.getKey() + ") " + entry.getValue());
        }

        while (true) {
            System.out.print("Enter the number of the group: ");
            String line = input.nextLine().trim();
            try {
                int selection = Integer.parseInt(line);
                if (groupMap.containsKey(selection)) {
                    return groupMap.get(selection);
                } else {
                    System.out.println("Invalid selection. Please enter a number from the list.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }

    private Map<String, String> readFullGroupRoster() {
        Map<String, String> roster = new HashMap<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(GROUPS_ROSTER_FILE))) {
            String line;
            boolean isHeader = true;
            while ((line = reader.readLine()) != null) {
                if (line.isEmpty()) continue;
                if (isHeader) {
                    isHeader = false;
                    continue;
                }

                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    String studentName = parts[0].trim();
                    String groupID = parts[1].trim().toUpperCase();
                    roster.put(studentName, groupID);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("Error: Roster file '" + GROUPS_ROSTER_FILE + "' not found.");
        } catch (IOException e) {
            System.out.println("Error reading roster file: " + e.getMessage());
        }
        return roster;
    }

    // --- Core Grading Logic Methods ---

    private int getMaxMarkForComponent(String componentName, List<String[]> gradesCriteria) {
        for (String[] criteria : gradesCriteria) {
            if (criteria[0].equalsIgnoreCase(componentName)) {
                try {
                    return Integer.parseInt(criteria[1]);
                } catch (NumberFormatException e) {
                    return -1;
                }
            }
        }
        return -1;
    }

    private void inputMarksForComponent(List<String> students, String componentName,
                                        Map<String, Map<String, String>> existingMarks, int maxMark) {

        System.out.println("\n--- Entering Marks for " + componentName + " (Max Mark: " + maxMark + ") ---");
        System.out.println("Enter the score for each student (or ENTER to skip/keep old score).");

        for (String student : students) {

            Map<String, String> studentData = existingMarks.getOrDefault(student, new HashMap<>());
            String currentMark = studentData.getOrDefault(componentName, "N/A");

            int newMark = -1;
            boolean validMark = false;

            while (!validMark) {
                System.out.printf("%-25s (Current: %s): ", student, currentMark);
                String line = input.nextLine().trim();

                if (line.isEmpty()) {
                    validMark = true;
                    continue;
                }

                try {
                    newMark = Integer.parseInt(line);
                    if (newMark >= 0 && newMark <= maxMark) {
                        validMark = true;
                    } else {
                        System.out.println("Mark must be between 0 and " + maxMark + ". Try again.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid number format. Please enter a whole number or press ENTER.");
                }
            }

            if (newMark != -1) {
                existingMarks.putIfAbsent(student, new HashMap<>());
                existingMarks.get(student).put(componentName, String.valueOf(newMark));
            }
        }
    }

    private void saveMarksToFile(String filename, Map<String, Map<String, String>> studentMarks) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(filename))) {
            for (Map.Entry<String, Map<String, String>> entry : studentMarks.entrySet()) {
                StringBuilder line = new StringBuilder(entry.getKey());

                for (Map.Entry<String, String> markEntry : entry.getValue().entrySet()) {
                    line.append(",").append(markEntry.getKey()).append(":").append(markEntry.getValue());
                }
                writer.println(line.toString());
            }
            System.out.println("\nSuccessfully saved marks to: " + filename);
        } catch (IOException e) {
            System.out.println("Error writing marks to file: " + e.getMessage());
        }
    }

    private String selectGradingComponent(List<String[]> gradesCriteria) {
        System.out.println("\nAvailable Grading Components:");
        for (int i = 0; i < gradesCriteria.size(); i++) {
            System.out.printf("  %d) %s (Weight: %s) %n", i + 1, gradesCriteria.get(i)[0], gradesCriteria.get(i)[1]);
        }

        while (true) {
            System.out.print("Enter the number of the component you want to grade (or 0 to cancel): ");
            String line = input.nextLine().trim();
            if (line.equals("0")) return null;

            try {
                int index = Integer.parseInt(line);
                if (index > 0 && index <= gradesCriteria.size()) {
                    return gradesCriteria.get(index - 1)[0]; // Return the component name
                } else {
                    System.out.println("Invalid selection. Please enter a number from the list.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
    }


    // --- Helper Methods (FIXED FILE EXTENSION HERE) ---

    private String getGradeFilename(String group) {
        // FIX: Changed from .txt to .csv to match GradeDivination saving format.
        return "grades_" + group + ".csv";
    }

    private String getMarksFilename(String group) {
        return "enterMarks_" + group + ".txt";
    }

    private List<String[]> readGradeCriteria(String fileName) {
        List<String[]> grade = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if(line.trim().isEmpty()) continue;
                String[] parts = line.split(" ");
                if (parts.length >= 2) {
                    String name = String.join(" ", Arrays.copyOf(parts, parts.length - 1));
                    String weight = parts[parts.length - 1];
                    grade.add(new String[]{name, weight});
                }
            }
        } catch (IOException e) {
            // Error is handled in the main method
        }
        return grade;
    }

    private List<String> readStudents(String fileName) {
        List<String> student = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    student.add(line.trim());
                }
            }
        } catch (IOException e) {
            System.out.println("Error Reading Students: " + e.getMessage());
        }
        return student;
    }

    private Map<String, Map<String, String>> readExistingMarks(String marksFileName) {
        Map<String, Map<String, String>> studentMarks = new HashMap<>();
        try {
            File marksFile = new File(marksFileName);
            if (marksFile.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(marksFile));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 1) {
                        String studentName = parts[0];
                        Map<String, String> studentMark = new HashMap<>();

                        for (int i = 1; i < parts.length; i++) {
                            String[] markParts = parts[i].split(":");
                            if (markParts.length == 2) {
                                studentMark.put(markParts[0], markParts[1]);
                            }
                        }
                        studentMarks.put(studentName, studentMark);
                    }
                }
                reader.close();
            }
        } catch (IOException e) {
            System.out.println("Error Reading Previous Marks: " + e.getMessage());
        }
        return studentMarks;
    }
}
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class GradeDivination {

    public void showGradeDivination() {
        System.out.println("== Grade Divination ==");

        boolean running = true;
        Scanner sc = new Scanner(System.in);

        while (running) {
            System.out.println("Enter the weights for each component (total must be 100):");

            System.out.print("Attendance/Participation: ");
            int cho1 = sc.nextInt();

            System.out.print("Quizzes/Small tests: ");
            int cho2 = sc.nextInt();

            System.out.print("Projects/Presentations: ");
            int cho3 = sc.nextInt();

            System.out.print("Assignments/Homework: ");
            int cho4 = sc.nextInt();

            System.out.print("Midterm Exam: ");
            int cho5 = sc.nextInt();

            System.out.print("Final Exam: ");
            int cho6 = sc.nextInt();

            int sum = cho1 + cho2 + cho3 + cho4 + cho5 + cho6;

            if (sum != 100) {
                System.out.println("The sum must be 100. Yours is " + sum + ". Please try again.\n");
            } else {
                System.out.println("The sum is 100.");

                // Save to file
                try (PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("grades.txt")))) {
                    pw.println("Attendance/Participation," + cho1);
                    pw.println("Quizzes/Small tests," + cho2);
                    pw.println("Projects/Presentations," + cho3);
                    pw.println("Assignments/Homework," + cho4);
                    pw.println("Midterm Exam," + cho5);
                    pw.println("Final Exam," + cho6);
                } catch (IOException e) {
                    System.out.println("Error writing file: " + e.getMessage());
                }

                System.out.print("Do you want to change anything? (y/n): ");
                String answer = sc.next();
                running = answer.equalsIgnoreCase("y");
            }
        }

        System.out.println("Grade division setup completed!");
    }
}

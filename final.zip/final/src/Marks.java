import java.io.*;
import java.util.*;

public class Marks {
    public void showMarks() {
        try {
            System.out.println("== Marks ==");

            // Read the criteria
            List<String[]> grades = readGrade("grades.txt");
            // Read student names
            List<String> students = readStudents("students.txt");
            // Read existing grades if available
            Map<String, Map<String, String>> studentMarks = ExistingGrades();

            // Display the table
            displayTable(grades, students, studentMarks);
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public List<String[]> readGrade(String fileName) {
        List<String[]> grade = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 2) {
                    grade.add(parts);
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Error Reading Grades: " + e.getMessage());
        }
        return grade;
    }

    public List<String> readStudents(String fileName) {
        List<String> student = new ArrayList<>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    student.add(line.trim());
                }
            }
            reader.close();
        } catch (IOException e) {
            System.out.println("Error Reading Students: " + e.getMessage());
        }
        return student;
    }

    public Map<String, Map<String, String>> ExistingGrades() {
        Map<String, Map<String, String>> studentMarks = new HashMap<>();
        try {
            File marksFile = new File("enterMarks.txt");
            if (marksFile.exists()) {
                BufferedReader reader = new BufferedReader(new FileReader(marksFile));
                String line;
                while ((line = reader.readLine()) != null) {
                    String[] parts = line.split(",");
                    if (parts.length >= 1) {
                        String studentName = parts[0];
                        Map<String, String> studentMark = new HashMap<>();

                        for (int i = 1; i < parts.length; i++) {
                            String[] markParts = parts[i].split(":");
                            if (markParts.length == 2) {
                                studentMark.put(markParts[0], markParts[1]);
                            }
                        }
                        studentMarks.put(studentName, studentMark);
                    }
                }
                reader.close();
            }
        } catch (IOException e) {
            System.out.println("Error Reading The Previous File: " + e.getMessage());
        }
        return studentMarks;
    }

    private void displayTable(List<String[]> grades, List<String> students,
                              Map<String, Map<String, String>> studentMarks) {

        // Calculate table width
        int tableWidth = 25 + (grades.size() * 18) + 12;

        System.out.println("\n" + "=".repeat(tableWidth));
        System.out.println("GRADES OVERVIEW");
        System.out.println("=".repeat(tableWidth));

        // Print header
        System.out.printf("%-25s", "STUDENT NAME");
        for (String[] grade : grades) {
            String displayName = grade[0] + "/" + grade[1];
            System.out.printf("│ %-15s", shortenString(displayName, 15));
        }
        System.out.printf("│ %-10s%n", "TOTAL");
        System.out.println("-".repeat(tableWidth));

        // Print student rows
        for (String student : students) {
            System.out.printf("%-25s", shortenString(student, 25));
            Map<String, String> marks = studentMarks.getOrDefault(student, new HashMap<>());
            int total = 0;

            for (String[] grade : grades) {
                String mark = marks.getOrDefault(grade[0], "-");
                System.out.printf("│ %-15s", shortenString(mark, 15));

                // Calculate total if mark is numeric
                if (!mark.equals("-") && mark.matches("\\d+")) {
                    total += Integer.parseInt(mark);
                }
            }
            System.out.printf("│ %-10d%n", total);
        }

        System.out.println("=".repeat(tableWidth));

        // Show summary
        System.out.println("\nStudents: " + students.size());
        System.out.println("Graded: " + studentMarks.size());
        System.out.println("Press Enter to continue...");
        try {
            new Scanner(System.in).nextLine();
        } catch (Exception e) {
            // Just continue
        }
    }

    private String shortenString(String text, int maxLength) {
        if (text.length() <= maxLength) {
            return text;
        }
        return text.substring(0, maxLength - 3) + "...";
    }
}
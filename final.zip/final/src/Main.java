import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc= new Scanner(System.in);
        boolean running =true;
        Timetable timetableService = new Timetable();
        GradeDivination gradeDivisionService = new GradeDivination();
        Marks marksService = new Marks();





        while (running){
            System.out.println("== Main Page ==");
            System.out.println("1.Lesson Timetable\n2.Grade Divition\n3.Enter Marks\n4.Put Absent Marks\n5.Absent Marks Timetable\n6.The Exam Protocol\n7.Exit");

            int choice;
            Scanner input =new Scanner(System.in);
            choice=input.nextInt();
            switch(choice){
              case 1:
                  timetableService.showTimetable();
              break;
              case 2:
                  gradeDivisionService.showGradeDivination();
              case 3:
                  marksService.showMarks();

              case 4:
                  //

              case 5:
                  //

              case 6:
                  //
              case 7:
                  running =false;
                  System.out.println("Goodbye!");
                  break;
              default:
                  System.out.println("Invalid choice");

          }
      }
    }
}
import java.io.*;
import java.util.*;
public class Timetable
{
    public void showTimetable() {
        System.out.println("== Lesson Timetable ==");
        File file = new File("timetable.txt");
        if (!file.exists()|| file.length()==0) {
            System.out.println("Timetable File Not Found");
            return;
        }
        try (BufferedReader br = new BufferedReader(new FileReader("timetable.txt"))) {
            String line;

            System.out.println("\n+----------+----------+----------+----------+----------+----------+----------+");
            System.out.println("|   Time   |  Monday  | Tuesday  | Wednesday| Thursday |  Friday  | Saturday |");
            System.out.println("+----------+----------+----------+----------+----------+----------+----------+");

            while ((line = br.readLine()) != null) {
                String[] p = line.split(",");


                System.out.printf("| %8s | %8s | %8s | %9s | %8s | %8s | %8s |%n",
                        p[0], p[1], p[2], p[3], p[4], p[5], p[6]);
            }

            System.out.println("+----------+----------+----------+----------+----------+----------+----------+");

        } catch (IOException e) {
            System.out.println("Error reading timetable: " + e.getMessage());
        }
    }



}
